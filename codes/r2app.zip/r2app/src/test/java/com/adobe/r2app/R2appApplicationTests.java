package com.adobe.r2app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class R2appApplicationTests {

    @Test
    void contextLoads() {
    }

}
