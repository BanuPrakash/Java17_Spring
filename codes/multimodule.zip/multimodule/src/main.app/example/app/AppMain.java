package example.app;

import core.util.WorkerUtil;

public class AppMain {
    public static void main(String[] args) {
        WorkerUtil.doSomething();
    }
}