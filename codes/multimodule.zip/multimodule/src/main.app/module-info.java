module main.app {
  requires core.app;
}