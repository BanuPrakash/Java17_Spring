package core.util;

public class WorkerUtil {
  public static void doSomething() {
      System.out.println("WorkerUtil working..");
  }
}